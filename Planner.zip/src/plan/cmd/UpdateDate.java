package plan.cmd;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import plan.biz.PlanBiz;
import plan.entity.PlanEntity;
import user.biz.UserBiz;
import user.entity.CharacterEntity;
import user.entity.UserEntity;


@WebServlet("/plan/UpdateDate")
public class UpdateDate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
    	response.setContentType("text/html;charset=UTF-8");
    	
    	String newStart_str = request.getParameter("newStart");
    	String newEnd_str = request.getParameter("newEnd");
    	String planId =request.getParameter("planId");
    	
    	HttpSession session = request.getSession();
    	UserEntity user = (UserEntity)session.getAttribute("user");
		try {
				
			    int num = newStart_str.indexOf("T");
        	    
			    System.out.println(newStart_str);
			    System.out.println(newEnd_str);
			    
			    PlanBiz biz = new  PlanBiz();
			    PlanEntity plan = new PlanEntity();
			    plan.setPlanId(planId);
			    plan.setPlanDateFrom(newStart_str.substring(0,num));
			    plan.setPlanDateFromTime(newStart_str.substring(num));
			    plan.setPlanDateTo(newEnd_str.substring(0,num));
			    plan.setPlanDateToTime(newEnd_str.substring(num));
			    plan.setUserId(user.getUserId());
			    System.out.println(">>"+newStart_str.substring(num));
			    System.out.println(">>"+newEnd_str.substring(num));
			    
			    int result =biz.updateDate(plan);
			  
			    if(result>0){
			    	
			    	RequestDispatcher rd = request.getRequestDispatcher("/plan/selectable.jsp");
			 		rd.forward( request, response );
			    	
			    }
			    
		} catch(Exception e) {
			RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
			request.setAttribute("message", "예상하지 못한 문제 발생");
			rd.forward( request, response );
		}
	}

}
