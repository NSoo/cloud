package plan.cmd;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import plan.biz.PlanBiz;
import plan.entity.PlanEntity;
import user.entity.UserEntity;

/**
 * Servlet implementation class RegisterPlan
 */
@WebServlet(urlPatterns={"/plan/RegisterPlan"})
public class RegisterPlan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
 	    request.setCharacterEncoding( "UTF-8" );
 	     UserEntity user = (UserEntity) session.getAttribute("user");
    	
    		try {
    			String planName =request.getParameter("planName");
    			String planCagetory =request.getParameter("planCagetory");
        		String planDateTo =request.getParameter("planDateTo");
        		String planDateFrom =request.getParameter("planDateFrom");
        		String planScore = request.getParameter("planScore");
        		String planRemark= request.getParameter("planDetail");
        		int num = planDateTo.indexOf("T");
        	    
        		
        		PlanEntity plan = new PlanEntity();
        		plan.setPlanName(planName);
        		plan.setCategoryId(planCagetory);
        		plan.setPlanDateFromTime(planDateFrom.substring(num));
        		plan.setPlanDateFrom(planDateFrom.substring(0,num));
        		plan.setPlanDateTo(planDateTo.substring(0,num));
        		plan.setPlanDateToTime(planDateTo.substring(num));
        		plan.setScoreId(planScore);
        		plan.setPlanRemark(planRemark);
        		plan.setUserId(user.getUserId());
        		
        		PlanBiz biz = new PlanBiz();
        		
				int result=biz.registerPlan(plan);
			
				if(result>0){
					
					result = biz.updateStatusIng(user.getUserId());
					if(result>0){

						RequestDispatcher rd = request.getRequestDispatcher("/plan/PlanList");
						rd.forward(request, response);
					}
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}        
	}

}
