package plan.cmd;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import plan.biz.PlanBiz;
import plan.entity.PlanEntity;
import user.entity.UserEntity;

/**
 * Servlet implementation class RegisterPlan
 */
@WebServlet(urlPatterns={"/plan/UpdatePlan"})
public class UpdatePlan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
 	    request.setCharacterEncoding( "UTF-8" );
 	     UserEntity user = (UserEntity) session.getAttribute("user");
    	
    		try {
    			String planId = request.getParameter("planId2");
    			String planDetail =request.getParameter("planDetail2");
        		PlanBiz biz = new PlanBiz();
        		PlanEntity updatePlan = new PlanEntity();
        		updatePlan.setPlanId(planId);
        		updatePlan.setUserId(user.getUserId());
        		updatePlan.setPlanRemark(planDetail);
        		
				int result = biz.updatePlan(updatePlan);
				
				if(result>0){
					RequestDispatcher rd = request.getRequestDispatcher("/plan/PlanList");
					rd.forward(request, response);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}        
	}

}
