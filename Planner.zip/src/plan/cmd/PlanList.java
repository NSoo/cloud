package plan.cmd;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import plan.biz.PlanBiz;
import plan.entity.PlanEntity;
import user.biz.UserBiz;
import user.entity.CharacterEntity;
import user.entity.UserEntity;


@WebServlet("/plan/PlanList")
public class PlanList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
    	response.setContentType("text/html;charset=UTF-8");
    	String userId = request.getParameter("userId");
		HttpSession session = request.getSession();
		UserEntity uEntity = new UserEntity();
		try {
			System.out.println(userId);
			uEntity = (UserEntity)session.getAttribute("user");
			CharacterEntity cEntity = new CharacterEntity(); 
			UserBiz uBiz = new UserBiz();
			PlanBiz planbiz =new PlanBiz();
			cEntity = uBiz.selectCharacter(uEntity.getUserId());
			System.out.println(userId);
			System.out.println(cEntity.getChacter_Id() + " " + cEntity.getImg_Id() + " " + cEntity.getUser_Id());
			System.out.println(cEntity.getChacter_Name() + " " + cEntity.getChacter_Exp() + " " + cEntity.getChacter_Birthday());
			ArrayList<PlanEntity> categoryList = planbiz.categoryList();
			session.setAttribute("categoryList", categoryList);
	
			
			RequestDispatcher rd = request.getRequestDispatcher("/plan/selectable.jsp");
			request.setAttribute("entity", cEntity);
			session.setAttribute("cEntity", cEntity);
            rd.forward( request, response );
		} catch(Exception e) {
			RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
			request.setAttribute("message", "예상하지 못한 문제 발생");
			rd.forward( request, response );
		}
	}

}
