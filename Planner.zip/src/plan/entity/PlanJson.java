package plan.entity;

import org.json.simple.JSONAware;
import org.json.simple.JSONObject;

public class PlanJson implements JSONAware {
	
	private String id;
	private String title;
	private String start;
	private String end;
	private String remark;
	private String planProcessing;
	private String score;
	private String categoryName;
	private String backgroundColor;
	



	public PlanJson(String id, String title, String start, String end,
			String remark, String planProcessing, String score ,String categoryName,String backgroundColor ) {
		this.id = id;
		this.title = title;
		this.start = start;
		this.end = end;
		this.remark = remark;
		this.planProcessing = planProcessing;
		this.score =score;
		this.categoryName=categoryName;
		this.backgroundColor=backgroundColor ;
	}




	@Override
	public String toJSONString() {
		
		JSONObject obj = new JSONObject();
		obj.put("id",id);
	    obj.put("title", title);
	    obj.put("start", start);
	    obj.put("end", end);
	    obj.put("remark",remark);
	    obj.put("planProcessing", planProcessing);
	    obj.put("score",score);
	    obj.put("categoryName", categoryName);
	    obj.put("color", backgroundColor );
	    return obj.toString();
	}

}
