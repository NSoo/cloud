package plan.entity;

public class PlanStatusEntity {
	private String planStatus_Id;
	private String planStatus_Fail;
	private String planStauts_Success;
	private String planStatus_Ing;
	private String planStatus_Total;
	private String user_Id;
	public PlanStatusEntity() {
		super();
	}
	public PlanStatusEntity(String planStatus_Id, String planStatus_Fail,
			String planStauts_Success, String planStatus_Ing,
			String planStatus_Total, String user_Id) {
		super();
		this.planStatus_Id = planStatus_Id;
		this.planStatus_Fail = planStatus_Fail;
		this.planStauts_Success = planStauts_Success;
		this.planStatus_Ing = planStatus_Ing;
		this.planStatus_Total = planStatus_Total;
		this.user_Id = user_Id;
	}
	public String getPlanStatus_Id() {
		return planStatus_Id;
	}
	public void setPlanStatus_Id(String planStatus_Id) {
		this.planStatus_Id = planStatus_Id;
	}
	public String getPlanStatus_Fail() {
		return planStatus_Fail;
	}
	public void setPlanStatus_Fail(String planStatus_Fail) {
		this.planStatus_Fail = planStatus_Fail;
	}
	public String getPlanStauts_Success() {
		return planStauts_Success;
	}
	public void setPlanStauts_Success(String planStauts_Success) {
		this.planStauts_Success = planStauts_Success;
	}
	public String getPlanStatus_Ing() {
		return planStatus_Ing;
	}
	public void setPlanStatus_Ing(String planStatus_Ing) {
		this.planStatus_Ing = planStatus_Ing;
	}
	public String getPlanStatus_Total() {
		return planStatus_Total;
	}
	public void setPlanStatus_Total(String planStatus_Total) {
		this.planStatus_Total = planStatus_Total;
	}
	public String getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}
	
	
	
}
