package plan.entity;

public class PlanEntity {
	
	private String planId;
	private String planName;
	private String planDateTo;
	private String planDateToTime;
	private String planDateFrom;
	private String planDateFromTime;
	private String planRemark;
	private String userId;
	private String scoreId;
	private String score;
	private String categoryId;
	private String categoryName;
	private String planProcessing;
	
	
	
	public String getPlanDateToTime() {
		return planDateToTime;
	}
	public void setPlanDateToTime(String planDateToTime) {
		this.planDateToTime = planDateToTime;
	}
	public String getPlanDateFromTime() {
		return planDateFromTime;
	}
	public void setPlanDateFromTime(String planDateFromTime) {
		this.planDateFromTime = planDateFromTime;
	}
	public String getPlanProcessing() {
		return planProcessing;
	}
	public void setPlanProcessing(String planProcessing) {
		this.planProcessing = planProcessing;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPlanDateTo() {
		return planDateTo;
	}
	public void setPlanDateTo(String planDateTo) {
		this.planDateTo = planDateTo;
	}
	public String getPlanDateFrom() {
		return planDateFrom;
	}
	public void setPlanDateFrom(String planDateFrom) {
		this.planDateFrom = planDateFrom;
	}
	public String getPlanRemark() {
		return planRemark;
	}
	public void setPlanRemark(String planRemark) {
		this.planRemark = planRemark;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getScoreId() {
		return scoreId;
	}
	public void setScoreId(String scoreId) {
		this.scoreId = scoreId;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	public PlanEntity(String planId, String planName, String planDateTo,
			String planDateFrom, String planRemark, String userId,
			String scoreId, String score, String categoryId, String categoryName ,String planProcessing) {
		super();
		this.planId = planId;
		this.planName = planName;
		this.planDateTo = planDateTo;
		this.planDateFrom = planDateFrom;
		this.planRemark = planRemark;
		this.userId = userId;
		this.scoreId = scoreId;
		this.score = score;
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.planProcessing =planProcessing;
	}
	public PlanEntity(){
		
	}
	
	
}
