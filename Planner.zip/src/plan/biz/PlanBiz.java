package plan.biz;

import static common.Util.JdbcUtil.close;
import static common.Util.JdbcUtil.commit;
import static common.Util.JdbcUtil.getConnection;
import static common.Util.JdbcUtil.rollback;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import plan.dao.PlanDao;
import plan.entity.PlanEntity;
import plan.entity.PlanStatusEntity;
import user.entity.UserEntity;

public class PlanBiz {

	public int registerPlan(PlanEntity plan) throws SQLException  {
		
		Connection conn = null;
    	PlanDao dao = new PlanDao();
    	int result = 0;
    	
    	try {
			
    		conn = getConnection();
			result = dao.registerPlan(plan, conn);
			
			if(result>0) commit(conn);		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			rollback(conn);
			throw e;
		} finally {
			close(conn);			
		}
    	
    	return result;
	}

	public ArrayList<PlanEntity> planList(UserEntity entity) throws SQLException {
	
		Connection conn = null;
		PlanDao dao = new PlanDao();
		
		ArrayList<PlanEntity> planList = null;
		try {
			
			conn= getConnection();
			planList = dao.planList(entity,conn);
			
		} catch (SQLException e) {
			throw e;
		}finally{
			close(conn);
		}
		
		return planList; 
	}
	
	public PlanStatusEntity selectPlanStatus(String userId) throws SQLException{
		PlanStatusEntity pEntity = new PlanStatusEntity();
		Connection conn = null;
		PlanDao dao = new PlanDao();
		System.out.println("??");
		try{
			conn= getConnection();
			pEntity = dao.selectPlanStatus(userId,conn);
			return pEntity;
		}finally{
			close(conn);
		}
	}
		public ArrayList<PlanEntity> categoryList()  throws SQLException{
		
		Connection conn = null;
		PlanDao dao = new PlanDao();
		
		ArrayList<PlanEntity> categoryList = null;
		try {
			
			conn= getConnection();
			categoryList = dao.categoryList(conn);
			
		} catch (SQLException e) {
			throw e;
		}finally{
			close(conn);
		}
		
		return categoryList; 
	}

		public int updatePlan(PlanEntity updatePlan)throws SQLException{
			
			Connection conn = null;
			PlanDao dao = new PlanDao();
			int result=0;
			try {
				
				conn= getConnection();
				result = dao.updatePlan(updatePlan,conn);
				if(result>0) commit(conn);	
				
			} catch (SQLException e) {
				rollback(conn);
				throw e;
			}finally{
				close(conn);
			}
			
			return result; 
		}

		public int donePlan(PlanEntity donePlan) throws SQLException{
			
			Connection conn = null;
			PlanDao dao = new PlanDao();
			int result=0;
			try {
				
				conn= getConnection();
				result = dao.donePlan(donePlan,conn);
				if(result>0) commit(conn);	
				
			} catch (SQLException e) {
				rollback(conn);
				throw e;
			}finally{
				close(conn);
			}
			
			return result; 
		}

		public int updateStatusSuccess(String userId) throws SQLException{
			
			Connection conn = null;
			PlanDao dao = new PlanDao();
			int result=0;
			try {
				
				conn= getConnection();
				result = dao.updateStatusSuccess(userId,conn);
				if(result>0) commit(conn);	
				
			} catch (SQLException e) {
				rollback(conn);
				throw e;
			}finally{
				close(conn);
			}
			
			return result; 
		}

		public int updateStatusIng(String userId) throws SQLException{
			
			Connection conn = null;
			PlanDao dao = new PlanDao();
			int result=0;
			try {
				
				conn= getConnection();
				result = dao.updateStatusIng(userId,conn);
				if(result>0) commit(conn);	
				
			} catch (SQLException e) {
				rollback(conn);
				throw e;
			}finally{
				close(conn);
			}
			
			return result; 
		}

		public int updateDate(PlanEntity plan) throws SQLException{
			
			Connection conn = null;
			PlanDao dao = new PlanDao();
			int result=0;
			try {
				
				conn= getConnection();
				result = dao.updateDate(plan,conn);
				if(result>0) commit(conn);	
				
			}catch (SQLException e) {
				rollback(conn);
				throw e;
			}finally{
				close(conn);
			}
			
			return result; 
		}

		public int deletePlan(PlanEntity deletePlan) throws SQLException{
			
			Connection conn = null;
			PlanDao dao = new PlanDao();
			int result=0;
			try {
				
				conn= getConnection();
				result = dao.deletePlan(deletePlan,conn);
				if(result>0) commit(conn);	
				
			}catch (SQLException e) {
				rollback(conn);
				throw e;
			}finally{
				close(conn);
			}
			
			return result; 
		}

		public int deletePlanStatus(PlanEntity deletePlan) throws SQLException{
			
			Connection conn = null;
			PlanDao dao = new PlanDao();
			int result=0;
			try {
				
				conn= getConnection();
				result = dao.deletePlanStatus(deletePlan,conn);
				if(result>0) commit(conn);	
				
			}catch (SQLException e) {
				rollback(conn);
				throw e;
			}finally{
				close(conn);
			}
			
			return result; 
		}
}