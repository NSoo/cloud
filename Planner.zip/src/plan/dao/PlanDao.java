package plan.dao;

import static common.Util.JdbcUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import plan.entity.PlanEntity;
import plan.entity.PlanStatusEntity;
import user.entity.UserEntity;

public class PlanDao {

	public int registerPlan(PlanEntity plan, Connection conn) throws SQLException{

    	PreparedStatement pstmt = null;
    	int result=0;
    	String sql = " INSERT INTO TB_PLAN(PLAN_ID,PLAN_NAME,PLAN_DATETO,PLAN_DATEFROM,PLAN_REMARK,USER_ID,SCORE_ID,CATEGORY_ID,PLAN_PROCESSING, PLAN_DATETOTIME, PLAN_DATEFROMTIME) "+ 
				 " VALUES( (SELECT 'PLAN_' ||(CASE WHEN COUNT(*) =0 THEN '001' ELSE LPAD(MAX((SUBSTR(PLAN_ID, 6, 3))+1),3,0)  END) FROM TB_PLAN " +
			     " WHERE USER_ID = ? ), ? , ? , ? , ? , ? , ? ,? ,'N',?,?) ";

		try {

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1,plan.getUserId());
			pstmt.setString(2, plan.getPlanName());
			pstmt.setString(3, plan.getPlanDateTo());
			pstmt.setString(4, plan.getPlanDateFrom());
			pstmt.setString(5, plan.getPlanRemark());
			pstmt.setString(6, plan.getUserId());
			pstmt.setString(7, plan.getScoreId());
			pstmt.setString(8, plan.getCategoryId());
			pstmt.setString(9, plan.getPlanDateToTime());
			pstmt.setString(10,plan.getPlanDateFromTime());

			result = pstmt.executeUpdate();

			if(result < 1 ){
				throw new SQLException();
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw e;
		} finally{
			close(pstmt);
		}

		return result;
	}

	public ArrayList<PlanEntity> planList(UserEntity entity, Connection conn) throws SQLException{

		PreparedStatement pstmt = null;

		ArrayList<PlanEntity> planList = new ArrayList<PlanEntity>();
		ResultSet rs =null;

		String sql = " SELECT PLAN_ID , PLAN_NAME, TO_CHAR(TO_DATE(PLAN_DATETO),'YYYY-MM-DD') AS PLAN_DATETO, PLAN_DATEFROM, PLAN_REMARK, PLAN_PROCESSING, "
			       + " B.CATEGORY_NAME AS CATEGROY_NAME, B.CATEGORY_ID AS CATEGORY_ID, C.SCORE_ID AS SCORE_ID, C.SCORE_SCORE AS SCORE_SCORE ,"
				   + " PLAN_DATETOTIME, PLAN_DATEFROMTIME "
			       + " FROM TB_PLAN A "
			       + " JOIN TB_CATEGORY B "
			       + " ON A.CATEGORY_ID= B.CATEGORY_ID "
			       + " JOIN TB_SCORE C "
			       + " ON A.SCORE_ID = C.SCORE_ID WHERE USER_ID = ? ";
	
		

		try{

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, entity.getUserId());
			rs = pstmt.executeQuery();
		
			
		  while(rs.next()){
			  String PLAN_ID =rs.getString("PLAN_ID");
			  String PLAN_NAME =rs.getString("PLAN_NAME");
			  String PLAN_DATETO = rs.getString("PLAN_DATETO");
			  String PLAN_DATEFROM =  rs.getString("PLAN_DATEFROM");
			  String PLAN_REMARK =  rs.getString("PLAN_REMARK");
			  String PLAN_PROCESSING =rs.getString("PLAN_PROCESSING");
			  String SCORE_ID =rs.getString("SCORE_ID");
			  String SCORE_SCORE =rs.getString("SCORE_SCORE");
			  String CATEGORY_ID =rs.getString("CATEGORY_ID");
			  String CATEGORY_NAME = rs.getString("CATEGROY_NAME");
			  String PLAN_DATETOTIME =rs.getString("PLAN_DATETOTIME");
			  String PLAN_DATEFROMTIME =rs.getString("PLAN_DATEFROMTIME");
				
			  PlanEntity plan = new PlanEntity();
			  plan.setPlanId(PLAN_ID);
			  plan.setPlanName(PLAN_NAME);
			  plan.setPlanDateTo(PLAN_DATETO);
			  plan.setPlanDateFrom(PLAN_DATEFROM);
			  plan.setPlanRemark(PLAN_REMARK);
			  plan.setScoreId(SCORE_ID);
			  plan.setCategoryId(CATEGORY_ID);
			  plan.setPlanProcessing(PLAN_PROCESSING);
			  plan.setCategoryName(CATEGORY_NAME);
			  plan.setScore(SCORE_SCORE);
			  plan.setPlanDateToTime(PLAN_DATETOTIME);
			  plan.setPlanDateFromTime(PLAN_DATEFROMTIME);
			  
			  planList.add(plan);
			  
		  }
		
		}catch(Exception e){
			throw e;

		}finally{
			close(rs);
			close(pstmt);
		}

		return planList;
	}

	public PlanStatusEntity selectPlanStatus(String userId, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs =null;
		String sql = "SELECT PLANSTATUS_ID"
				+ ",PLANSTATUS_FAIL"
				+ ",PLANSTAUTS_SUCCESS"
				+ ",PLANSTATUS_ING"
				+ ",PLANSTATUS_TOTAL"
				+ ",USER_ID "
				+ "FROM TB_PLANSTATUS "
				+ "WHERE USER_ID = ?";
		try{	
			System.out.println(sql);
			PlanStatusEntity pEntity = new PlanStatusEntity();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			rs = pstmt.executeQuery();
			while(rs.next()){
				pEntity.setPlanStatus_Id(rs.getString(1));
				pEntity.setPlanStatus_Fail(rs.getString(2));
				pEntity.setPlanStauts_Success(rs.getString(3));
				pEntity.setPlanStatus_Ing(rs.getString(4));
				pEntity.setPlanStatus_Total(rs.getString(5));
				pEntity.setUser_Id(rs.getString(6));
			}
			return pEntity;
		}catch(Exception e){
			throw e;

		}finally{
			close(rs);
			close(pstmt);
		}
	}
	
	public ArrayList<PlanEntity> categoryList(Connection conn) throws SQLException{
		
		PreparedStatement pstmt = null;
		
		ArrayList<PlanEntity> planList = new ArrayList<PlanEntity>();
		ResultSet rs =null;
		
		String sql = " SELECT CATEGORY_ID, CATEGORY_NAME FROM TB_CATEGORY ";
	
		
		try{
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
		
			
		  while(rs.next()){
			  String CATEGORY_ID =rs.getString("CATEGORY_ID");
			  String CATEGORY_NAME =rs.getString("CATEGORY_NAME");
				
			  PlanEntity plan = new PlanEntity();
			  plan.setCategoryId(CATEGORY_ID);
			  plan.setCategoryName(CATEGORY_NAME);
			  
			  planList.add(plan);
			  
		  }
			
		}catch(Exception e){
			 throw e;
		
		}finally{
			close(rs);
			close(pstmt);
		}
		
		return planList;
	}

	public int updatePlan(PlanEntity updatePlan, Connection conn) throws SQLException{
		
		PreparedStatement pstmt = null;
		int result =0;
		
		String sql = " UPDATE TB_PLAN SET PLAN_REMARK = ? WHERE PLAN_ID= ? AND USER_ID = ? ";

		
		try{
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, updatePlan.getPlanRemark());
			pstmt.setString(2, updatePlan.getPlanId());
			pstmt.setString(3, updatePlan.getUserId());
			result = pstmt.executeUpdate();
		    
		}catch(Exception e){
			 throw e;
		
		}finally{
			close(pstmt);
		}
		
		return result;
	}

	public int donePlan(PlanEntity donePlan, Connection conn) throws SQLException{
		
		PreparedStatement pstmt = null;
		int result =0;
		
		String sql = " UPDATE TB_PLAN SET PLAN_PROCESSING='Y', PLAN_DATETO= TO_CHAR(SYSDATE,'YYYY-MM-DD')  WHERE PLAN_ID= ? AND USER_ID = ? ";
	
		
		try{
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, donePlan.getPlanId());
			pstmt.setString(2, donePlan.getUserId());
			result = pstmt.executeUpdate();
		    
		}catch(Exception e){
			 throw e;
		
		}finally{
			close(pstmt);
		}
		
		return result;
	}

	public int updateStatusSuccess(String userId, Connection conn)throws SQLException{
		
		PreparedStatement pstmt = null;
		int result =0;
		
		String sql = " UPDATE TB_PLANSTATUS SET PLANSTAUTS_SUCCESS=PLANSTAUTS_SUCCESS + 1, PLANSTATUS_ING =PLANSTATUS_ING-1 WHERE  USER_ID = ? ";
	
		
		try{
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			result = pstmt.executeUpdate();
		    
		}catch(Exception e){
			 throw e;
		
		}finally{
			close(pstmt);
		}
		
		return result;
	}

	public int updateStatusIng(String userId, Connection conn) throws SQLException{
		
		PreparedStatement pstmt = null;
		int result =0;
		
		String sql = " UPDATE TB_PLANSTATUS SET PLANSTATUS_ING =PLANSTATUS_ING+1 ,PLANSTATUS_TOTAL = PLANSTATUS_TOTAL+1 WHERE  USER_ID = ? ";
	
		
		try{
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			result = pstmt.executeUpdate();
		    
		}catch(Exception e){
			 throw e;
		
		}finally{
			close(pstmt);
		}
		
		return result;
	}

	public int updateDate(PlanEntity plan, Connection conn)  throws SQLException{
		
		PreparedStatement pstmt = null;
		int result =0;
		
		String sql = " UPDATE TB_PLAN SET PLAN_DATEFROM= ?, PLAN_DATETO= ?, PLAN_DATEFROMTIME = ? , PLAN_DATETOTIME = ?  WHERE PLAN_ID= ? AND USER_ID = ? ";
	
		
		try{
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, plan.getPlanDateFrom());
			pstmt.setString(2, plan.getPlanDateTo());
			pstmt.setString(3, plan.getPlanDateFromTime());
			pstmt.setString(4, plan.getPlanDateToTime());
			pstmt.setString(5, plan.getPlanId());
			pstmt.setString(6, plan.getUserId());
			result = pstmt.executeUpdate();
		    
		}catch(Exception e){
			 throw e;
		
		}finally{
			close(pstmt);
		}
		
		return result;
	}

	public int deletePlan(PlanEntity deletePlan, Connection conn) throws SQLException{
		
		PreparedStatement pstmt = null;
		int result =0;
		
		String sql = " DELETE TB_PLAN  WHERE PLAN_ID= ? AND USER_ID = ? ";
	
		
		try{
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, deletePlan.getPlanId());
			pstmt.setString(2, deletePlan.getUserId());
			result = pstmt.executeUpdate();
		    
		}catch(Exception e){
			 throw e;
		
		}finally{
			close(pstmt);
		}
		
		return result;
	}

	public int deletePlanStatus(PlanEntity deletePlan, Connection conn) throws SQLException{
		
		PreparedStatement pstmt = null;
		int result =0;
		
		String sql = " UPDATE TB_PLANSTATUS SET PLANSTATUS_ING =PLANSTATUS_ING-1 ,PLANSTATUS_TOTAL = PLANSTATUS_TOTAL-1 WHERE  USER_ID = ? ";
	
		
		try{
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, deletePlan.getUserId());
			result = pstmt.executeUpdate();
		    
		}catch(Exception e){
			 throw e;
		
		}finally{
			close(pstmt);
		}
		
		return result;
	}


	
}
