package member.cmd;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.Session;

@WebServlet("/member/LoginMember")
public class LoginMember extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding( "UTF-8" );
		
		String userId = request.getParameter("userId");
		String userPw = request.getParameter("userPw");
		
//		MemberBiz biz = new MemberBiz();
//		MemberEntity entity = null;
		HttpSession session = request.getSession();
		
		try {
//			entity = biz.loginMember(userId);
//			if(entity == null) {
//				RequestDispatcher rd = request.getRequestDispatcher( "/member/memberRegisterForm.jsp" );
//				rd.forward( request, response );
//			} else {
//				session.setAttribute("memberId", userId);
//				
//				RequestDispatcher rd = request.getRequestDispatcher( "/menu/MenuList" );
//				rd.forward( request, response );
//			}
			RequestDispatcher rd = request.getRequestDispatcher( "/menu/MenuList" );
			session.setAttribute("user", userId);
			rd.forward( request, response );
		} catch(Exception e) {
			RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
			request.setAttribute("message", "예상하지 못한 문제 발생");
			rd.forward( request, response );
		}
		
	}

}
