package user.dao;

import static common.Util.JdbcUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import common.Util.JdbcUtil;
import user.entity.CharacterEntity;
import user.entity.UserEntity;

public class UserDao {

	public UserEntity selectUser(String userId, Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateUser(UserEntity user, Connection conn) {
		// TODO Auto-generated method stub

	}

	public int registerUser(UserEntity user, Connection conn) throws SQLException{

		PreparedStatement pstmt = null;
		int rs = 0;
		String sql = " INSERT INTO TB_USER(USER_ID,USER_PW,USER_BIRTHDAY,USER_EMAIL,PLANSTATUS_SCORE) "
					+" VALUES (?,?,?,?,0) ";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getUserId());
			pstmt.setString(2, user.getUserPw());
			pstmt.setString(3, user.getUserBirth());
			pstmt.setString(4, user.getUserEmail());

			
			rs = pstmt.executeUpdate();

			if(rs == 0) throw new SQLException("회원 등록 중 에러 발생");

			
			if(rs <1) throw new SQLException("회원 등록 중 에러 발생");

		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw e;
		} finally {
			close(pstmt);
		}

		return rs;
	}

	public int registerCharacter(CharacterEntity character, UserEntity user, Connection conn) throws SQLException{

		PreparedStatement pstmt = null;
		int rs = 0;
		String sql = " INSERT INTO TB_CHACTER "
					+" VALUES (?,?,0,TO_CHAR(SYSDATE,'YYYY-MM-DD'),?) ";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, character.getChacter_Id());
			pstmt.setString(2, character.getChacter_Name());
			pstmt.setString(3, user.getUserId());
			rs = pstmt.executeUpdate();

			if(rs<1) throw new SQLException("캐릭터 등록 중 에러 발생");
		} catch (SQLException e) {
			throw e;
		} finally {
			close(pstmt);
		}

		return rs;
	}
	
	public int registerPlanStatus(CharacterEntity character, UserEntity user, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		int rs = 0;
		String sql = "INSERT INTO TB_PLANSTATUS VALUES ((SELECT CONCAT('PLANSTATUS_',LPAD(MAX(SUBSTR(PLANSTATUS_ID,12,3))+1,3,0)) from TB_PLANSTATUS),0,0,0,0,?)";
		try {
			System.out.println(sql);
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, user.getUserId());
			System.out.println("!11");
			rs = pstmt.executeUpdate();
			return rs;
		}catch (SQLException e) {
			throw e;
		} finally {
			close(pstmt);
		}

	}

	public UserEntity loginUser(String userId, String userPw, Connection conn) throws SQLException{

		UserEntity entity = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = " SELECT USER_ID, USER_BIRTHDAY, USER_EMAIL "
				+" FROM TB_USER "
				+" WHERE USER_ID = ? AND USER_PW = ?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPw);
			rs = pstmt.executeQuery();

			if(rs.next()){
				entity = new UserEntity();
				entity.setUserId(rs.getString(1));
				entity.setUserBirth(rs.getString(2));
				entity.setUserEmail(rs.getString(3));
			}

			if(entity == null) {
				throw new SQLException("아이디 또는 비밀번호가 틀렸습니다.");
			}

		} catch (SQLException e) {
			throw e;
		} finally {
			close(rs);
			close(pstmt);
		}

		return entity;
	}
	public CharacterEntity selectCharacter(String userId, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		String sql = "SELECT A.CHACTER_ID CHACTER_ID"
				+ ", A.CHACTER_NAME CHACTER_NAME"
				+ ", A.CHACTER_EXP CHACTER_EXP"
				+ ", A.CHACTER_BIRTHDAY CHACTER_BIRTHDAY"
				+ ", A.USER_ID USER_ID"
				+ ", C.IMG_ID IMG_ID "
				+ ", E.CHAT_REMARK CHAT_REMARK "
				+ "FROM TB_CHACTER A JOIN TB_PLANSTATUS B ON A.USER_ID = B.USER_ID "
				+ "JOIN TB_IMG C ON A.CHACTER_ID = C.CHARCTER_ID "
				+ "JOIN TB_USER D ON A.USER_ID = D.USER_ID "
				+ "JOIN TB_CHAT E ON D.PLANSTATUS_SCORE = E.CHAT_CONDITION "
				+ "WHERE (1=1) "
				+ "AND SUBSTR(IMG_ID,19,10) = CASE WHEN D.PLANSTATUS_SCORE IN (0,1,2) THEN 'Angry' "
				+"WHEN D.PLANSTATUS_SCORE IN (3,4,5) THEN 'Worry' "
				+"WHEN D.PLANSTATUS_SCORE IN (6,7,8,9) THEN 'Normal' "
				+"ELSE 'Happy' END " 
				+"AND SUBSTR(C.IMG_ID,17,1) = CASE WHEN A.CHACTER_EXP < 11 THEN '1' "
				+"WHEN A.CHACTER_EXP < 21 THEN '2' "
				+"WHEN A.CHACTER_EXP < 31 THEN '3' "
				+"WHEN A.CHACTER_EXP < 41 THEN '4' "
				+"ELSE '5' END "                                    
				+"AND A.USER_ID = ?";
		CharacterEntity cEntity = new CharacterEntity();
		System.out.println(sql);
		try{
			pstmt = conn.prepareStatement( sql );
			pstmt.setString(1, userId);
			result = pstmt.executeQuery();
			System.out.println("??11");
			if(result.next()){
				cEntity.setChacter_Id(result.getString(1));
				cEntity.setChacter_Name(result.getString(2));
				cEntity.setChacter_Exp(result.getString(3));
				cEntity.setChacter_Birthday(result.getString(4));
				cEntity.setUser_Id(result.getString(5));
				cEntity.setImg_Id(result.getString(6));
				cEntity.setChacter_Chat(result.getString(7));
			}
			return cEntity;
		}catch ( SQLException e ) {
			// TODO: handle exception
			throw e;
		} finally {
			JdbcUtil.close(pstmt);
		}
	}
	
	public int caracterEntityUpdate(String userId, String characterId, String chacter_Name, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "UPDATE TB_CHACTER SET CHACTER_NAME = ? WHERE CHACTER_ID = ? AND USER_ID = ?";
		try{
			pstmt = conn.prepareStatement( sql );
			pstmt.setString(1, chacter_Name);
			pstmt.setString(2, characterId);
			pstmt.setString(3, userId);
			result = pstmt.executeUpdate();
			return result;
		}catch ( SQLException e ) {
			// TODO: handle exception
			throw e;
		} finally {
			JdbcUtil.close(pstmt);
		}
	}
	

}
