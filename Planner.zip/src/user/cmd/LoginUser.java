package user.cmd;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import plan.biz.PlanBiz;
import plan.entity.PlanEntity;
import user.biz.UserBiz;
import user.entity.UserEntity;

/**
 * Servlet implementation class LoginUser
 */
@WebServlet("/user/LoginUser")
public class LoginUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding( "UTF-8" );
		
		String userId = request.getParameter("userId");
		String userPw = request.getParameter("userPw");
		
		UserBiz biz = new UserBiz();
		UserEntity entity = null;
		HttpSession session = request.getSession();
		
		PlanBiz planbiz = new PlanBiz();
		ArrayList<PlanEntity> planList = new ArrayList<PlanEntity>();
		
		try {
			entity = biz.userLogin(userId, userPw);
			planList = planbiz.planList(entity);
			RequestDispatcher rd = request.getRequestDispatcher("/plan/PlanList");
			request.setAttribute("planList", planList);
			request.setAttribute("size",planList.size());
			session.setAttribute("user", entity);
			rd.forward(request, response);
			
		} catch(Exception e) {
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
			request.setAttribute("message", "예상하지 못한 문제 발생");
			rd.forward( request, response );
		}
	}

}
