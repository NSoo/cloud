package user.cmd;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.User;

import user.biz.UserBiz;
import user.entity.CharacterEntity;
import user.entity.UserEntity;


@WebServlet("/user/RegisterUser")
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		String userId = request.getParameter("userid");
		String InputPassword1 = request.getParameter("InputPassword1");
		String InputBirth = request.getParameter("InputBirth");
		String InputEmail = request.getParameter("InputEmail");
		String imgFileName = request.getParameter("imgFileName");
		String charcterName = request.getParameter("charcterName");
		
		UserEntity entity = new UserEntity();
		entity.setUserId(userId);
		entity.setUserPw(InputPassword1);
		entity.setUserBirth(InputBirth);
		entity.setUserEmail(InputEmail);
		
		UserBiz biz = new UserBiz();
	
		CharacterEntity characterEntity = new CharacterEntity();
		
		int start_num= imgFileName.indexOf("/img/")+5;
		int end_num =imgFileName.indexOf(".png");
		characterEntity.setChacter_Id(imgFileName.substring(start_num,end_num));
		characterEntity.setImg_Id(imgFileName.substring(start_num));
		characterEntity.setChacter_Name(charcterName);
		
		
		try {
			int result= biz.registerUser(entity,characterEntity);
			RequestDispatcher rd = request.getRequestDispatcher( "/index.jsp" );
		    rd.forward( request, response );
			
		} catch (Exception e) {
			RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
			request.setAttribute("message", "예상하지 못한 문제 발생");
			rd.forward( request, response );
		}
	}

}
