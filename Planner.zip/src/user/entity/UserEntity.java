package user.entity;

public class UserEntity {
	private String userId;
	private String userPw;
	private String userEmail;
	private String userBirth;
	private String characterId;
	private String characterName;
	private String characterExp;
	private String characterImgFileName;
	private String characterBirth;
	
	public UserEntity() {
		super();
	}

	public UserEntity(String userId, String userPw, String userEmail, String userBirth,
			String characterId, String characterName, String characterExp,
			String characterImgFileName, String characterBirth) {
		super();
		this.userId = userId;
		this.userEmail = userEmail;
		this.userBirth = userBirth;
		this.characterId = characterId;
		this.characterName = characterName;
		this.characterExp = characterExp;
		this.characterImgFileName = characterImgFileName;
		this.characterBirth = characterBirth;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserPw() {
		return userPw;
	}
	
	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}
	
	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserBirth() {
		return userBirth;
	}

	public void setUserBirth(String userBirth) {
		this.userBirth = userBirth;
	}

	public String getCharacterId() {
		return characterId;
	}

	public void setCharacterId(String characterId) {
		this.characterId = characterId;
	}

	public String getCharacterName() {
		return characterName;
	}

	public void setCharacterName(String characterName) {
		this.characterName = characterName;
	}

	public String getCharacterExp() {
		return characterExp;
	}

	public void setCharacterExp(String characterExp) {
		this.characterExp = characterExp;
	}

	public String getCharacterImgFileName() {
		return characterImgFileName;
	}

	public void setCharacterImgFileName(String characterImgFileName) {
		this.characterImgFileName = characterImgFileName;
	}

	public String getCharacterBirth() {
		return characterBirth;
	}

	public void setCharacterBirth(String characterBirth) {
		this.characterBirth = characterBirth;
	}
}
