package user.entity;

public class CharacterEntity {
	private String chacter_Id;
	private String chacter_Name;
	private String chacter_Exp;
	private String chacter_Birthday;
	private String user_Id;
	private String img_Id;
	private String chacter_Chat;
		
	public CharacterEntity() {
		super();
	}
	public CharacterEntity(String chacter_Id, String chacter_Name,
			String chacter_Exp, String chacter_Birthday, String user_Id,
			String img_Id, String chacter_Chat) {
		super();
		this.chacter_Id = chacter_Id;
		this.chacter_Name = chacter_Name;
		this.chacter_Exp = chacter_Exp;
		this.chacter_Birthday = chacter_Birthday;
		this.user_Id = user_Id;
		this.img_Id = img_Id;
		this.chacter_Chat = chacter_Chat;
	}
	public String getChacter_Id() {
		return chacter_Id;
	}
	public void setChacter_Id(String chacter_Id) {
		this.chacter_Id = chacter_Id;
	}
	public String getChacter_Name() {
		return chacter_Name;
	}
	public void setChacter_Name(String chacter_Name) {
		this.chacter_Name = chacter_Name;
	}
	public String getChacter_Exp() {
		return chacter_Exp;
	}
	public void setChacter_Exp(String chacter_Exp) {
		this.chacter_Exp = chacter_Exp;
	}
	public String getChacter_Birthday() {
		return chacter_Birthday;
	}
	public void setChacter_Birthday(String chacter_Birthday) {
		this.chacter_Birthday = chacter_Birthday;
	}
	public String getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}
	public String getImg_Id() {
		return img_Id;
	}
	public void setImg_Id(String img_Id) {
		this.img_Id = img_Id;
	}

	public String getChacter_Chat() {
		return chacter_Chat;
	}
	public void setChacter_Chat(String chacter_Chat) {
		this.chacter_Chat = chacter_Chat;
	}
}
