package user.biz;

import static common.Util.JdbcUtil.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import common.Util.JdbcUtil;
import user.dao.UserDao;
import user.entity.CharacterEntity;
import user.entity.UserEntity;

public class UserBiz {
	
	public UserEntity selectUser(String userId) throws Exception {
		
		Connection conn = null;
		UserDao dao = new UserDao();
		UserEntity entity = null;
		
		try {
			conn = getConnection();
			entity = dao.selectUser(userId, conn);
			
		} catch(Exception e) {
			throw e;
		} finally {
			close(conn);
		}
		
		return entity;
	}
	
	public int updateMenu(UserEntity user) throws Exception {
		
		Connection conn = null;
		UserDao dao = new UserDao();
		int rs = 0;
		
		try {
			conn = getConnection();
			dao.updateUser(user, conn);
			commit(conn);
		} catch(Exception e) {
			throw e;
		} finally {
			close(conn);
		}
		
		return rs;
	}
	
	public int registerUser(UserEntity user, CharacterEntity character) throws Exception {
		
		Connection conn = null;
		UserDao dao = new UserDao();
		int rs = 0;
		
		try {
			//회원등록
			conn = getConnection();
			
			dao.registerUser(user, conn);
			commit(conn);
			
			//캐릭터 등록
			dao.registerCharacter(character, user, conn);
			commit(conn);
			
			dao.registerPlanStatus(character, user, conn);
			commit(conn);
			
			//이미지 등록
			
		} catch(Exception e) {
			throw e;
		} finally {
			close(conn);
		}
		
		return rs;
	}
	
	public UserEntity userLogin(String userId, String userPw) throws Exception {
		
		Connection conn = null;
		UserDao dao = new UserDao();
		UserEntity rs = null;
		
		try {
			conn = getConnection();
			rs = dao.loginUser(userId, userPw,conn);
			commit(conn);
		} catch(Exception e) {
			throw e;
		} finally {
			close(conn);
		}
		
		return rs;
	}
	
	public CharacterEntity selectCharacter(String userId) throws SQLException{
		CharacterEntity cEntity = new CharacterEntity();
		Connection conn = null;
		UserDao uDao = new UserDao();
		try{
			conn = getConnection();
			cEntity = uDao.selectCharacter(userId, conn);
			return cEntity;
		}finally{
			JdbcUtil.close(conn);
		}
		
	}
	
	public int caracterEntityUpdate(String userId, String characterId, String chacter_Name) throws SQLException{
		Connection conn = null;
		UserDao uDao = new UserDao();
		int result = 0;
		try{
			conn = getConnection();
			result = uDao.caracterEntityUpdate(userId, characterId, chacter_Name, conn);
			if(result > 0){
				commit(conn);
			}else{
				rollback(conn);
			}
			return result;
		}finally{
			JdbcUtil.close(conn);
		}
	}

	
}
