$(document).ready(function(){
	$("#loginButton").click(function() {
		if ($('#userId').val() == "") {
			alert("사번을 입력해 주세요.");
			return;
		}
		
		if ($('#userPw').val() == "") {
			alert("비밀번호를 입력해 주세요.");
			return;
		}

		$('#loginForm').submit();
	});
	
	$('#registerButton').click(function() {
		location.href = getContextPath() + "/user/registerUser.jsp";
	});
});

// ContextPath 구하는 함수
function getContextPath() {
	var hostIndex = location.href.indexOf(location.host) + location.host.length;
	return location.href.substring(hostIndex, location.href.indexOf('/', hostIndex + 1));
};