$(document).ready(function() {
	$('#InputBirth').datepicker( {
		format: 'yyyymmdd',
		language: 'kr',
		autoclose: true,
		todayHighlight: true
	});
	
	$("#registerButton").click(function(){
		
		$("#imgFileName").val($(".item").children().first().attr('src'));
		$("#registerUserForm").submit();
	});
	
	$('#cancelButton').click(function(){
		console.log(getContextPath());
		location.href = getContextPath() + "/index.jsp";
	});
});

//ContextPath 구하는 함수
function getContextPath() {
	var hostIndex = location.href.indexOf(location.host) + location.host.length;
	return location.href.substring(hostIndex, location.href.indexOf('/', hostIndex + 1));
};