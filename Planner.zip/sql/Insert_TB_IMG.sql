
-- img Insert 

-- 1

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV01_Angry','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV02_Angry','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV03_Angry','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV04_Angry','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV05_Angry','Character_01');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV01_Happy','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV02_Happy','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV03_Happy','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV04_Happy','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV05_Happy','Character_01');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV01_Normal','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV02_Normal','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV03_Normal','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV04_Normal','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV05_Normal','Character_01');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV01_Worry','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV02_Worry','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV03_Worry','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV04_Worry','Character_01');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_01_LV05_Worry','Character_01');

-- 2


INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV01_Angry','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV02_Angry','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV03_Angry','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV04_Angry','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV05_Angry','Character_02');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV01_Happy','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV02_Happy','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV03_Happy','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV04_Happy','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV05_Happy','Character_02');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV01_Normal','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV02_Normal','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV03_Normal','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV04_Normal','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV05_Normal','Character_02');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV01_Worry','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV02_Worry','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV03_Worry','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV04_Worry','Character_02');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_02_LV05_Worry','Character_02');

-- 3


INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV01_Angry','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV02_Angry','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV03_Angry','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV04_Angry','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV05_Angry','Character_03');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV01_Happy','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV02_Happy','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV03_Happy','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV04_Happy','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV05_Happy','Character_03');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV01_Normal','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV02_Normal','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV03_Normal','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV04_Normal','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV05_Normal','Character_03');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV01_Worry','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV02_Worry','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV03_Worry','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV04_Worry','Character_03');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_03_LV05_Worry','Character_03');


INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV01_Angry','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV02_Angry','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV03_Angry','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV04_Angry','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV05_Angry','Character_04');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV01_Happy','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV02_Happy','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV03_Happy','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV04_Happy','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV05_Happy','Character_04');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV01_Normal','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV02_Normal','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV03_Normal','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV04_Normal','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV05_Normal','Character_04');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV01_Worry','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV02_Worry','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV03_Worry','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV04_Worry','Character_04');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_04_LV05_Worry','Character_04');

-- 5


INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV01_Angry','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV02_Angry','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV03_Angry','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV04_Angry','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV05_Angry','Character_05');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV01_Happy','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV02_Happy','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV03_Happy','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV04_Happy','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV05_Happy','Character_05');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV01_Normal','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV02_Normal','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV03_Normal','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV04_Normal','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV05_Normal','Character_05');

--
INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV01_Worry','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV02_Worry','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV03_Worry','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV04_Worry','Character_05');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_05_LV05_Worry','Character_05');

-- 6


INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV01_Angry','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV02_Angry','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV03_Angry','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV04_Angry','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV05_Angry','Character_06');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV01_Happy','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV02_Happy','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV03_Happy','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV04_Happy','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV05_Happy','Character_06');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV01_Normal','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV02_Normal','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV03_Normal','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV04_Normal','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV05_Normal','Character_06');

--

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV01_Worry','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV02_Worry','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV03_Worry','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV04_Worry','Character_06');

INSERT INTO TB_IMG(IMG_ID,CHARCTER_ID)
VALUES('Character_06_LV05_Worry','Character_06');
